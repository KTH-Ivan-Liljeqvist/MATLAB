function y=myfun(x)
y=sqrt(x+2);
